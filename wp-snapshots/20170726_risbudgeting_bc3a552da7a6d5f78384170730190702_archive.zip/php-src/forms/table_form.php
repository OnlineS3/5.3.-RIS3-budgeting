<?php

function create_parent($conn) {
    
    $headers_ini = array('RIS3 priority','Funding source','Intervention field','Form of finance');
    $row_no = 1;
    $user_id = 1;
    
    $dd_res = get_dd_res($conn,$user_id);
    echo "<div class='parent-div'>";
    
    echo "<div class='table-div'>";
    
    echo "<table class='budget-table parent' id='main-table'>";

    // render cols
    echo "<thead><tr>";
    echo "<th class='base headcol'>RIS3 priority</th>";
    echo "<th class='base'>Measures</th>";
    echo "<th class='base'>Programme</th>";
    echo "<th class='extra hide'>Objective</th>";
    echo "<th class='extra hide'>Intervention</th>";
    echo "<th class='extra hide'>Form of finance</th>";
    echo "<th class='extra hide'>Funding source</th>";
    echo "<th class='comment-td extra hide'>Add comment</th>";
    echo "<th class='btn-td'></th>";
    
    echo "</tr></thead>";
    
    echo "<tbody>";
    for($i=0;$i<$row_no;$i++) {
        $cls = ($i==1)? 'active' : '$i';
        $type = ($i%2==0) ? 'even' : 'odd';
        
        $p_id = 'p_'.$i;
        echo "<tr class='$cls $type' id='1'>
            
        <td class='priority-td textarea base headcol' id='1_priority'>
            <textarea name='1_priority' class='priority' type='text' placeholder='description…'></textarea>
        </td>

        <td id='1_measure' class='measures measure-td list base disable'><button class='add-measure' id='add-measure'>+ define measures</button><p class='hide'></p></td>
        <td id='1_programme' class='program program-td list disable'><p class='load-measure'>&#8208;&#8208;</p><ul id='1-programme-ul' class='ellipse dashed hide'></ul><input name='1_1_p' type='text' class='hide' id='0-programme-text'/></td>
        <td id='1_object' class='object program-td list extra disable hide'><p class='load-measure'>&#8208;&#8208;</p><ul id='1-object-ul' class='ellipse dashed hide'></ul><input name='1_1_p' type='text' class='hide' id='0-object-text'/></td>
        <td id='1_inter' class='funding fund-td list extra disable hide'><p class='load-measure'>&#8208;&#8208;</p><ul id='1-inter-ul' class='ellipse dashed hide'></ul><input name='1_1_p' type='text' class='hide' id='0-inter-text'/></td>
        <td id='1_finance' class='inter inter-td list extra disable hide'><p class='load-measure'>&#8208;&#8208;</p><ul id='1-finance-ul' class='ellipse dashed hide'></ul> <input name='1_2_p' type='text' class='hide' id='0-finance-text'/></td>
        <td id='1_funding' class='finance fin-td list extra disable hide'><p class='load-measure'>&#8208;&#8208;</p><ul id='-funding-ul' class='ellipse dashed hide'></ul> <input name='1_3_p' type='text' class='hide' id='0-funding-text'/></td>
        <td id='1_comment' class='comment-td extra hide'><input type='text' class='hide' id='1-comment' name='1_comment'/><i class='fa fa-commenting' aria-hidden='true' onclick='return set_comment(1);'></i></td>
        
        <td class='del-td hide'><div><a href='#' onclick='delRow(1)' class='del-row'>
        <i class='fa fa-times' aria-hidden='true'></i></div></td>
        
        </tr>";
    }
    
    echo "</tbody>";
    
    echo "</table>";
    
    echo "<input type='text' class='hide' name='prio_rows' id='prio_rows' value='1'/>";
    
    echo "<input id='budget-cols' type='text' class='hide' name='budget_cols' value='0'/>";
    
    $object = $dd_res['object_json'];
    $inter = $dd_res['inter_json'];
    $finance = $dd_res['finance_json'];
    $funding = $dd_res['funding_json'];
    
    echo "</div>";
    
    echo "<button id='new-prio' class='add-item-alt prio' onclick='return addParentRow({table:\"main-table\", object:$object, inter:$inter,finance:$finance,funding:$funding});'>"
            . "<i class='fa fa-plus' aria-hidden='true'></i>Add Priority</button><div class='add-row-lb'>Add Priority</div>";
  
    echo "<button class='add-item-alt year hide' onclick='return addCol({table:\"main-table\"});'>"
    . "<i class='fa fa-plus ' aria-hidden='true'></i>Add Year</button>";
    
    echo "</div>";
    
    echo "<input type='text' id='active-parent' class='hide' value='1'/>";
}

function create_child($conn) {
    
    $headers_ini = array('Measure','Funding source','Intervention field','Form of finance');
    $row_no = 1;
    $col_no = 5;
    
    $user_id = 1;
	
    $dd_res = get_dd_res($conn,$user_id);
    
    $object = $dd_res['object_json'];
    $inter = $dd_res['inter_json'];
    $finance = $dd_res['finance_json'];
    $funding = $dd_res['funding_json'];
    
    echo "<div class='child-div'>";
    echo "<div class='inner'>";
    echo "<input id='measure_rows_1' type='text' class='hide' name='measure_rows_1' value='1'/>";
    
    echo "<table class='budget-table child' id='c_1'>";

    echo "<thead><tr>";
    echo "<th id='1_0_0_c'>Measure</th>";
    echo "<th id='1_0_1_c' class='add-budget'></th>";
    echo "<th id='1_0_1_c'>Programme<i class='fa fa-info-circle' aria-hidden='true'></i></th>";
    echo "<th id='1_0_1_c' class='extra'>Objective<i class='fa fa-info-circle' aria-hidden='true'></i></th>";
    echo "<th id='1_0_1_c' class='extra'>Intervention<i class='fa fa-info-circle' aria-hidden='true'></i></th>";
    echo "<th id='1_0_2_c' class='extra'>Form of finance<i class='fa fa-info-circle' aria-hidden='true'></i></th>";
    echo "<th id='1_0_3_c' class='extra'>Funding source<i class='fa fa-info-circle' aria-hidden='true'></i></th>";
    echo "<th class='del-td extra'></th>";
    echo "</tr></thead>";

    echo "<tbody>";
    for($i=0;$i<$row_no;$i++) {
        $cls = ($i==1)? 'active' : '';
        $type = ($i%2==0) ? 'even' : 'odd';
        
        $child_row = $i+1;
        
        echo "<tr class='$cls $type' id='1'>
            <td class='measure-td textarea' id='1_1_0_c'>
                <textarea name='1_1_measure' id='1_1_measure' class='measure' type='text' placeholder='measure... '></textarea>
                <input class='hide' id='budget_rows_1_1' type='text' name='budget_rows_1_1' value='0'/>
            </td>
            
            <td class='add-budget-td'>
                <button class='btn-primary button add-budget' id='add-1' onclick='return new_budget({budget_id:1,object:$object,inter:$inter,finance:$finance,funding:$funding});'>Add budget</button>
                <input class='hide' id='active-child' value='1'/>
            </td>
            
            <td class='budget-tr empty' colspan='7'>
                <table class='budgets'>
                </table>
            </td>
            
            <td class='del-td extra hide'>
                <div><a href='#' class='del-row' onclick='delRow(1,1)' id='child-$i'><i class='fa fa-times' aria-hidden='true'></i></a></div></a>
            </td>
        </tr>";
    }
    
    echo "</tbody>";
    echo "</table>";
    
    echo "</div>";
    
    echo "<button id='add-child-row' class='add-item-alt' onclick='return addChildRow({object:$object,inter:$inter,finance:$finance,funding:$funding});'><i class='fa fa-plus' aria-hidden='true'></i>Add Measure</button></div>";
    
}

