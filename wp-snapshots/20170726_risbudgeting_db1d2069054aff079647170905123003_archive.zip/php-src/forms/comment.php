
<div class='popup-box comment-form'>
    <div class='popup-content'>
        <p class='popup-title'>Enter your comments</p>
        <textarea class='description'  id='comment' cols='56' rows='7' placeholder='' type='text' value=''></textarea>
        
        <div class='btn-area'>
            <button class='confirm-btn' onclick='return return_comment()'>OK</button>
            <button style='color: #949494 !important;' onclick='return close_comment()'>Cancel</button>
        </div>
    </div>
    
<input id='prio-id' type='text' class='hide' />
	
</div>