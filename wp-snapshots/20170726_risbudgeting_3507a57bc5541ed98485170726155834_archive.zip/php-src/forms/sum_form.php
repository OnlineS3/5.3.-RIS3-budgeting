<?php

if (isset($_POST['filter_results'])) {
    
    $group_type = $_POST['group_col'][0];
        
    $prio_filters=$object_filters=$inter_filters=$fin_filters=$fund_filters=array();
    
    $filters = array('prio'=>$prios,'object'=>$objects,
        'inter'=>$inters,'finance'=>$finances,'funding'=>$funds);
    
    $summary_tbl = get_summary($conn,$user_id,$filters,$show_col,$group_type);
    
    $headers = array('group_col'=>$group_type,'prio'=>'Priority','object'=>'Objective',
        'inter'=>'Intervention','finance'=>'Finance','funding'=>'Funding',
        'year'=>'Year','planned_val'=>'Planned Value','committed_val'=>'Committed Value','spent_val'=>'Spent Value');

    $years = array_unique(array_map(function ($i) { return $i['year']; }, $summary_tbl));
    
    $budget_tbl = array('year','planned_val','committed_val','spent_val');
    
    echo "<div class='results'>";
    echo "<table class='budget-table summary'>";
    echo "<thead>";
    $i=0;
    foreach ($headers as $key=>$header) {
        
        if(($show_cols[$key]==1) && $key != $group_type) {
            $cls = ($key == 'group_col') ? 'group_col' : '';
            $val = ($key == 'group_col') ? $headers[$header] : $header;
            echo "<th class='$cls'>$val</th>";
            $i++;
        }
    }
    
    foreach ($years as $year) {
        echo "<th style='padding-bottom:0'><table class='budget-headers'><tr><td colspan='3' class='year-header'>$year</td></tr><tr><td>Planned Value</td><td>Committed Value</td><td>Spent Value</td></tr></table></th>";
    }
    
    echo "</thead>";
    echo "<tbody>";
    if($summary_tbl) {
        $group_prev = '';
        foreach ($summary_tbl as $row) {
            $group_val = $row['row_id'];
            if ($group_prev==$group_val) {
                foreach ($row as $key=>$cell) {
                    if (in_array($key, $budget_tbl)) {
                        $budget_res[$key] = $cell;
                    }
                }
                $planned_val = $budget_res['planned_val'];
                $committed_val = $budget_res['committed_val'];
                $spent_val = $budget_res['spent_val'];
                echo "<td class='budget-vals'><table><tr><td>$planned_val</td><td>$committed_val</td><td>$spent_val</td></tr></table></td>";
                continue;
            }
            
            echo "<tr>";
            $i=0;
            $budget_res = array();
            foreach ($row as $key=>$cell) {
                
                if (in_array($key, $budget_tbl)) {
                    $budget_res[$key] = $cell;
                }
                
                if(($show_cols[$key]==1) && $key != $group_type) {
                    
                    if(strripos($cell,',') == strlen($cell)-1) {
                        $cell = substr($cell,1,strlen($cell)-2);
                    }
                    
                    $cell = utf8_encode(str_replace(',','<hr>',$cell)); 
                    $cls = ($key == 'group_col') ? 'group_col' : '';
                    echo "<td class='$cls'>$cell</td>";
                    $i++;
                }
                
            }
            
            $planned_val = $budget_res['planned_val'];
            $committed_val = $budget_res['committed_val'];
            $spent_val = $budget_res['spent_val'];
            
            echo "<td class='budget-vals'><table><tr><td>$planned_val</td><td>$committed_val</td><td>$spent_val</td></tr></table></thd>";
            
            $group_prev = $group_val;
            
            
        }
    }
    
    echo "</tbody>";
    echo "</table>";

    echo "<div class='btn-section'>
        <div class='ddl-menu-primary'><button class='export-btn ddl-menu-button'>Download Data</button>
        <i class='fa fa-download' aria-hidden='true'></i>
        <div class='ddl-menu-content'><a href='#'>Download XLS<i class='fa fa-file-excel-o' aria-hidden='true'></i></a>
        <a href='#'>Download Word<i class='fa fa-file-word-o' aria-hidden='true'></i></a></div></div>
        <button class='next-btn'>Show Graphs</button><i class='fa fa-chevron-right' aria-hidden='true'></i>
        </div>";
    
    echo "</div>";
}
