<?php


function get_dd_res($conn,$user_id) {
    $fund_encoded = $inter_encoded = array();
    
    $prio_res = exec_select($conn, "SELECT id, description FROM priority WHERE user_id=$user_id");
    $object_res = exec_select($conn, "SELECT * FROM objective");
    $object_json = json_encode($object_res);
    $fund_res = exec_select($conn, "SELECT * FROM fund_forms");
    $inter_res = exec_select($conn, "SELECT * FROM intervention");
    $fin_res = exec_select($conn, "SELECT * FROM fin_forms");
    $fin_json = json_encode($fin_res);
    
    for($x = 0; $x < count($fund_res); $x++) {
        $fund_id = $fund_res[$x]['id'];
        $fund_desc = utf8_encode($fund_res[$x]['description']);
        array_push($fund_encoded,array('id'=>$fund_id,'description'=>$fund_desc));
    }

    $fund_json = json_encode($fund_encoded);
    
    for($x = 0; $x < count($inter_res); $x++) {
        $inter_id = $inter_res[$x]['id'];
        $inter_desc = $inter_id . '-' . utf8_encode($inter_res[$x]['description']);
        array_push($inter_encoded,array('id'=>$inter_id,'description'=>utf8_encode($inter_res[$x]['description'])));
        $inter_json = normalize_input(json_encode($inter_encoded));
    }
    
    return array('prio'=>$prio_res,'object'=>$object_res,'funding'=>$fund_res,'inter'=>$inter_res,'finance'=>$fin_res,
        'object_json'=>$object_json,'funding_json'=>$fund_json,'inter_json'=>$inter_json,'finance_json'=>$fin_json);
}

function get_summary($conn,$user_id,$filters,$show_col,$group_type) {
    
    $user_id = 1;
    
    $tbl_res = array();
    
    $sql = create_sql($user_id,$group_type,$filters);

    $tbl_res = exec_select($conn,$sql);
    
    
    return $tbl_res;
    
}

function create_sql($user_id,$group_table,$filters) {
    $prio = $filters['prio'];
    $object = $filters['object'];
    $inter = $filters['inter'];
    $finance = $filters['finance'];
    $funding = $filters['funding'];
    
    $sql_str = "SELECT '$group_table' as group_table, 
            $group_table.id AS row_id,
            concat($group_table.id,'-',$group_table.description) as group_col,
        group_concat(distinct prio.description) AS prio,
        group_concat(distinct coalesce(concat(object.id,'-',object.description),'')) AS object,
        group_concat(distinct coalesce(concat(inter.id,'-',inter.description),'')) AS inter,
        group_concat(distinct coalesce(concat(finance.id,'-',finance.description),'')) AS finance,
        group_concat(distinct funding.description) AS funding,
        coalesce(mea_budget.year,'') AS year,
        sum(coalesce(mea_budget.planned_val,0)) AS planned_val,
        sum(coalesce(mea_budget.committed_val,0)) AS committed_val,
        sum(coalesce(mea_budget.spent_val,0)) AS spent_val
    FROM measure mea
    JOIN priority prio ON prio.id = mea.prio_id AND (prio.id IN " . $prio . ")
    LEFT JOIN mea_obj mea_obj ON mea.id = mea_obj.mea_id
    LEFT JOIN objective object ON object.id = mea_obj.obj_id
    LEFT JOIN mea_inter mea_inter ON mea.id = mea_inter.mea_id
    LEFT JOIN intervention inter ON inter.id = mea_inter.inter_id
    LEFT JOIN mea_fin mea_fin ON mea.id = mea_fin.mea_id
    LEFT JOIN fin_forms finance ON finance.id = mea_fin.fin_id
    LEFT JOIN mea_fund mea_fund ON mea.id = mea_fund.mea_id
    LEFT JOIN fund_forms funding ON funding.id = mea_fund.fund_id
    LEFT JOIN mea_budget mea_budget ON mea.id = mea_budget.mea_id 
    WHERE prio.user_id = $user_id AND 
    (EXISTS 
	(SELECT 1 FROM mea_obj mea_obj, objective object 
	WHERE mea.id = mea_obj.mea_id AND object.id = mea_obj.obj_id AND object.id IN 
	" . $object  . ")
	OR NOT EXISTS (SELECT 1 FROM mea_obj mea_obj WHERE mea.id = mea_obj.mea_id)) AND  
    (EXISTS 
	(SELECT 1 FROM mea_inter mea_inter, intervention inter 
	WHERE mea.id = mea_inter.mea_id AND inter.id = mea_inter.inter_id AND inter.id IN 
	" . $inter  . ")
	OR NOT EXISTS (SELECT 1 FROM mea_inter mea_inter WHERE mea.id = mea_inter.mea_id)) AND 
    (EXISTS 
	(SELECT 1 FROM mea_fin mea_fin, fin_forms fin 
	WHERE mea.id = mea_fin.mea_id AND fin.id = mea_fin.fin_id AND fin.id IN 
        " . $finance . ")
	OR NOT EXISTS (SELECT 1 FROM mea_fin mea_fin WHERE mea.id = mea_fin.mea_id)) AND
    (EXISTS 
	(SELECT 1 FROM mea_fund mea_fund, fund_forms fund 
	WHERE mea.id = mea_fund.mea_id AND fund.id = mea_fund.fund_id AND fund.id IN 
        " . $funding . ")
	OR NOT EXISTS (SELECT 1 FROM mea_fund mea_fund WHERE mea.id = mea_fund.mea_id))
    GROUP BY $group_table.id, coalesce(mea_budget.year,'')";
    
    
    return $sql_str;
}