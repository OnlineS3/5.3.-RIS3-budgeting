<?php

?>


<div class='steps'>
    <div class='choice active'>
        <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
        <p>Budget Values</p>
    </div>
    <div class='choice init'>
        <i class="fa fa-table" aria-hidden="true"></i>
        <p>Data Analysis</p>
    </div>
    <div class='choice init'>
        <i class="fa fa-line-chart" aria-hidden="true"></i>
        <p>Charts</p>
    </div>
</div>