<?php

echo "<div class='step-2'>";

echo "<p id='intro-text'><span>"
    . "Lorem Ipsum is simply dummy text of the printing and typesetting industry. "
    . "Lorem Ipsum has been the industry s standard dummy text ever since the 1500s, when an unknown printer took a</span>"
    . "<a href='#'><i class='fa fa-angle-double-right' aria-hidden='true'></i></a></p>";

include "php-src/forms/filter_form.php";

echo "<div class='filter-btns'>"
        . "<input class='button btn-primary ' id='reset-btn' name='filter_results'" 
        . "value='Reset' type='submit'>" 
        . "<i class='fa fa-refresh' id='reset-icon' aria-hidden='true'></i>"
        . "<input class='button btn-primary ' id='search-btn' name='filter_results'" 
        . "value='Apply' type='submit'>" 
        . "<i class='fa fa-refresh' id='search-icon' aria-hidden='true'></i>"
        . "</div>";

include "php-src/forms/sum_form.php";

echo "</div>";