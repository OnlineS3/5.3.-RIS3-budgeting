<?php

$years = array('2013','2014','2015','2016','2017','2018','2019','2020');

$user_id = 1;

echo "<div class='step-1'>";

echo "<div class='section fill-years'><div class='title-1' style='margin-top: 0;margin-bottom: 9px;'>"
    . "<p style='padding-top:0'>1. Years for budgeting <i class='fa fa-info-circle' aria-hidden='true'></i></p></div>";

echo "<p class='tip'>Choose the years ..:</p>";

echo "<div class='guide one hide'>choose the years you want to include in your analysis <i class='fa fa-times'></i></div>";

echo "<select id='choose-years' class='choose-years chosen-select' data-placeholder='year ..' >";
echo "<option value=''></option>";
foreach ($years as $year) {
    echo "<option>$year</option>";
}

echo "</select>";

echo "<span class='show-years'>Selected years:</span>";

echo "<table id='selected-years' cellspacing='7'><tr></tr></table></div>";

echo "<div class='section fill-prios'><div class='title-1' style='width: 340px;'>"
    . "<p>2. Definition of priorities<i class='fa fa-info-circle' aria-hidden='true'></i></div>";
//echo "</p><span class='extra-cols'>all cols</span><input type='checkbox' class='all_cols'>";

echo "<div class='guide two hide'>create your priorities adding a description<i class='fa fa-times'></i></div>";

echo "<p class='tip' style='display: inline-block'>Define the priorities ..:</p>";
echo "<input id='show-prio-cols' class='hide' type='checkbox'/><label for='show-prio-cols' class='show-columns' style='color: #3875d7;'>Show extra columns <i class='fa fa-columns'></i></label>";

create_parent($conn);

echo "</div>";

echo "<div class='section hide fill-measures'><div class='title-1 '><p>3. Measures per Priority<i class='fa fa-info-circle' aria-hidden='true'></i></p></div>";

echo "<div class='guide three hide'>create measures' table per priority adding budgets per measure<i class='fa fa-times'></i></div>";

echo "<p class='tip' style='display: inline-block'>Define the measures for the priority:</p>";
echo "<input id='show-measure-cols' class='hide' type='checkbox' checked/><label class='show-columns' for='show-measure-cols' style='color: #8cba54;'>Hide extra columns</button>"
. "<i class='fa fa-columns' style='left: 6px;position: relative;'></i></label>";

create_child($conn);

echo "</div>";

include 'php-src/forms/budget_form.php';

echo "</div>";

echo "<div class='btn-section-in'>";
echo "<button class='export-btn' onclick='return exportMainXLS();'>Download Data</button> <i class='fa fa-download' aria-hidden='true'></i>";
echo "<button class='next-btn' name='save-data' disabled>Data Analysis</button><i class='fa fa-chevron-right' aria-hidden='true'></i>";
echo "</div>";


