<?php

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['save-data'])) {
    
    $user_id=1;
    
    $prio_rows = $_POST['row_count'];
    $budget_cols = $_POST['budget_cols'];
    
    for ($i=1;$i<=$prio_rows;$i++) {
        $prio_name = $i . '_0_p';
        $funding_name = $i . '_1_p';    
        $inter_name = $i . '_2_p'; 
        $finance_name = $i . '_3_p'; 
        $planned_name = $i . '_5_p';
        $committed_name = $i . '_6_p';
        $spent_name = $i . '_7_p';
        
        $prio_val = $_POST[$prio_name];
        $funding_val = $_POST[$funding_name];
        $inter_val = $_POST[$inter_name];
        $finance_val = $_POST[$finance_name];
        $planned_val = $_POST[$planned_name];
        $committed_val = $_POST[$committed_name];
        $spent_val = $_POST[$spent_name];
        
        $funding_val = str_replace("<li>","",str_replace("</li>","-",$funding_val));
        $inter_val = str_replace("<li>","",str_replace("</li>","-",$inter_val));
        $finance_val = str_replace("<li>","",str_replace("</li>","-",$finance_val));
        
        $object_val = '';
        
        $prio_id = exec_ins($conn, "INSERT INTO priority (user_id,description) "
                . "VALUES ($user_id,'$prio_val')");
        
        
        if (! $prio_id>0) {
            echo ' error ';
        } else {
            
            for ($i=1;$i<=$prio_rows;$i++) {
                
                $rows_id = 'child_rows_' . $i;
                $child_rows = $_POST[$rows_id];
                
                for ($y=1;$y<=$child_rows;$y++) {
                    
                    $mea_name = $i . '_' . $y . '_measure';
                    $mea_descr = $_POST[$mea_name];
                    
                    $mea_id = exec_ins($conn, "INSERT INTO measure (prio_id,description) "
                        . "VALUES ($prio_id,'$mea_descr')");
                    
                    if (! $mea_id>0) {
                        echo ' error ';
                    } else {
                        $fund_name = $i . '_' . $y . '_fund_source';
                        
                        if (isset($_POST[$fund_name])) {
                            foreach ($_POST[$fund_name] as $fund) {
                                exec_ins($conn, "INSERT INTO mea_fund (mea_id,fund_id) "
                                . "VALUES ($mea_id,'$fund')");
                            }
                        }
                        
                        $inter_name = $i . '_' . $y . '_inter_forms';
                        
                        if (isset($_POST[$inter_name])) {
                            foreach ($_POST[$inter_name] as $inter) {
                                exec_ins($conn, "INSERT INTO mea_inter (mea_id,inter_id) "
                                . "VALUES ($mea_id,'$inter')");
                            }
                        }
                        
                        
                        $fin_name = $i . '_' . $y . '_fin_forms';
                        
                        if (isset($_POST[$fin_name])) {
                            foreach ($_POST[$fin_name] as $fin) {
                                exec_ins($conn, "INSERT INTO mea_fin (mea_id,fin_id) "
                                . "VALUES ($mea_id,'$fin')");
                            }
                        }
                        
                        for ($z=0;$z<$budget_cols;$z++) {
                            
                            $year_name = $i . '_0_' . ($z+5) . '_c';
                            $planned_name = $i . '_' . $y . '_' . ($z+5) . '_planned_val';
                            $commit_name = $i . '_' . $y . '_' . ($z+5) . '_commit_val';
                            $spent_name = $i . '_' . $y . '_' . ($z+5) . '_spent_val';
                            
                            $year_val = $_POST[$year_name];
                            $planned_val = ($_POST[$planned_name]) ? $_POST[$planned_name] : 0;
                            $commit_val = ($_POST[$commit_name]) ? $_POST[$commit_name] : 0;
                            $spent_val = ($_POST[$spent_name]) ? $_POST[$spent_name] : 0;
                            
                            exec_ins($conn, "INSERT INTO mea_budget (mea_id,year,planned_val,committed_val,spent_val) "
                                    . "VALUES ($mea_id,'$year_val',$planned_val,$commit_val,$spent_val)");
                        }
                        
                    }
                }
            }
            
            
            
        }
        
        
        
    }
}