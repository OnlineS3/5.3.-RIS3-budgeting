<?php

?>


<div class='steps'>
    <div class='step-1 choice active'>
        <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
        <p>Budget Values</p>
    </div>
    <div class='step-2 choice init'>
        <i class="fa fa-table" aria-hidden="true"></i>
        <p>Data Analysis</p>
    </div>
    <div class='step-3 choice init'>
        <i class="fa fa-line-chart" aria-hidden="true"></i>
        <p>Benchmarking</p>
    </div>
</div>