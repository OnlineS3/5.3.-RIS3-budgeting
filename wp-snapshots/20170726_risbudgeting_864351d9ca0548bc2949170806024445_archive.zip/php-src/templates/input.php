<?php

include 'php-src/forms/load_tables.php';

$years = array('2013','2014','2015','2016','2017','2018','2019','2020');

$user_id = 1;

$tips[0] = "In this step, you have to 
        choose the years for which you want to elaborate the RIS3 financial plan. 
        Bear in mind that you should select the years in chronological order, 
        so that the budgeting tables are properly presented. All the selected 
        years will then appear in the budgeting tables.";

$tips[1] = "In this step, you should define the priorities of your RIS3 strategy. "
        . "For each priority you define, a new table will be generated below. "
        . "Bear in mind that this table is not editable; you have to insert more "
        . "detailed data in the next step so that this table is informed. At any "
        . "time, you can show or hide extra columns regarding (i) the thematic "
        . "objective, (ii) the intervention field, (iii) the form of finance and "
        . "(iv) the funding source. In order to add more information, click on "
        . "the “define measures” option and proceed to the next step. ";

$tips[2] = "In this step, you should describe the measures under each priority "
        . "of your RIS3 strategy. In order to add further details regarding "
        . "each measure, you have to click on the “add budget” option and fill "
        . "in the required form. You have to provide information regarding (i) "
        . "the operational programme under which this measure is funded, (ii) "
        . "the thematic objective, (iii) the intervention field, (iv) the form "
        . "of finance and (v) the funding source. The budget values should be "
        . "provided in terms of the planned, committed and spent amount of money. "
        . ""
        . "Don’t forget that at any time, you can show or hide extra columns "
        . "regarding (i) the thematic objective, (ii) the intervention field, "
        . "(iii) the form of finance and (iv) the funding source.";

echo "<div class='step-1 content'>";

echo "<form action='$home' id='budget-table' method='post'>";

echo "<div class='section fill-years'><div class='title-1' style='margin-top: 0;margin-bottom: 9px;'>"
    . "<p style='padding-top:0'>1. Years for budgeting ";
echo "<div class='tooltip-container'>
        <i class='fa fa-info-circle' aria-hidden='true'></i>
        <span class='tooltiptext arrow-left near tip-body'>$tips[0]</span></div></div>";

echo "<p class='tip'>Choose the years to elaborate the RIS3 financial plan:</p>";

$res = exec_select($conn, "SELECT 1 FROM priority WHERE user_id=$user_id");
$budget_exists = (count($res)>0) ? true : false;

if($budget_exists) {
    $budget_values = get_budget_values($conn,$user_id);
}

if($budget_exists) {
    load_years($years,$budget_values['years']);
} else {
    create_years($conn,$years);
}

echo "<div class='section fill-prios'><div class='title-1'>"
    . "<p>2. Definition of priorities";

echo "<div class='tooltip-container'>
        <i class='fa fa-info-circle' aria-hidden='true'></i>
        <span class='tooltiptext arrow-left near tip-body'>$tips[1]</span></div>";

echo "</div>";

$checked = isset($_POST['show_prio_cols']) ? 'checked' : '';

echo "<p class='tip' style='display: inline-block'>Define the priorities of your RIS3 strategy:</p>";
echo "<input id='show-prio-cols' name='show_prio_cols' class='hide' type='checkbox' $checked/><label for='show-prio-cols' class='show-columns' style='color: #007ce2;'>Show extra columns <i class='fa fa-columns'></i></label>";

if($budget_exists) {
    load_parent($conn,$user_id,$budget_values['years'],$budget_values['prios']);
} else {
    create_parent($conn);
}

echo "</div>";

$hide = 'hide';

if($budget_exists) {
    $res = exec_select($conn, "SELECT 1 FROM measure JOIN priority ON measure.prio_id = priority.id and priority.user_id = $user_id");
    $measure_exists = (count($res)>0) ? true : false;
    $prio_one = $budget_values['prios'][0]['prio_id'];
    $res = exec_select($conn, "SELECT 1 FROM measure JOIN priority ON measure.prio_id = $prio_one");
    $hide = (count($res)>0) ? '' : 'hide';
}

echo "<div class='section $hide fill-measures'><div class='title-1'><p>3. Measures per Priority <span id='prio-title'></span></p>";

echo "<div class='tooltip-container'>
        <i class='fa fa-info-circle' aria-hidden='true'></i>
        <span class='tooltiptext arrow-left near tip-body'>$tips[2]</span></div></div>";

$checked = isset($_POST['show_measure_cols']) ? 'checked' : '';

echo "<p class='tip' style='display: inline-block'>Describe the measures under this priority and add budget information:</p>";
echo "<input id='show-measure-cols' name='show_measure_cols[]' class='hide' type='checkbox' $checked/><label class='show-columns' for='show-measure-cols' style='color: #8cba54;'>Hide extra columns</button>"
. "<i class='fa fa-columns' style='left: 6px;position: relative;'></i></label>";

if($budget_exists) {
    load_children($conn,$user_id,$budget_values['years'],$budget_values['prios']);
} else {
    //echo "<div class='child-div'></div>";
    create_child($conn);
}

echo "</div>";


echo "<div class='step-1 btn-section'>
    <button class='export-btn' id='save-data' name='save-data'>Save<i class='fa fa-floppy-o' aria-hidden='true'></i></button>
    <button class='export-btn'>Clear<i class='fa fa-eraser' aria-hidden='true'></i></button> 
    <button class='export-btn' onclick='return exportMainXLS(\"budgets.xlsx\");'>Download<i class='fa fa-download' aria-hidden='true'></i></button> 
    <button class='next-btn' disabled>Publish<i class='fa fa-download' aria-hidden='true'></i></button> 
    <button class='next-btn' id='data-analysis' name='data-analysis' style='width: 126px !important;' disabled>Data Analysis<i class='fa fa-chevron-right' aria-hidden='true'></i></button>
    </div>";
        
$current_prio = ($_POST['current_prio']) ? $_POST['current_prio'] : 1;

echo "<input type='text' id='active-parent' class='hide' name='current_prio' value='$current_prio'/>";
echo "<input type='text' id='del-years' class='hide' name='del_years'/>";

echo "</form>";

include 'php-src/forms/budget_form.php';

include 'php-src/forms/comment.php';



