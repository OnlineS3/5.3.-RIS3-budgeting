<?php

    include 'php-src/templates/header.php';
   
    $home = 'http://' . $_SERVER['SERVER_NAME'] . '/budgeting/home';

    $about_hide = $_SERVER["REQUEST_METHOD"] == "POST" ? 'hide' : '';
    
    echo "<div class='budgeting'>";
    
    echo "<div id='about' class='section-page $about_hide plain'>";
    include 'php-src/templates/about.php';
    echo "</div>";
    
    echo "<div id='docs' class='section-page hide plain'>";
    include 'php-src/templates/docs.html';
    echo "</div>";

    echo "<div id='guide' class='section-page hide plain'>";
    include 'php-src/templates/guide.php';
    echo "</div>";
    
    $tool_hide = $_SERVER["REQUEST_METHOD"] == "POST" ? '' : 'hide';
    
    echo "<div id='tool' class='tool-page section-page $tool_hide' style='min-height:40rem'>";
    include 'php-src/templates/tool.php';
    echo "</div>";
    
    
    echo "</div>";
    
    include 'sidebar.php';
    echo "</div>";
    include 'php-src/templates/footer.php';
    
?>