<?php

echo "<div class='step-2 content hide'>";

echo "<form action='$home' id='budget-results' method='post'>";

include "php-src/forms/filter_form.php";

echo "<div class='filter-btns'>"
        . "<input class='button btn-primary ' id='reset-btn' name='filter_results'" 
        . "value='Reset' type='submit' disabled>" 
        . "<i class='fa fa-refresh' id='reset-icon' aria-hidden='true'></i>"
        . "<button class='button btn-primary' id='filter_results' name='filter_results'>Apply</button>" 
        . "<i class='fa fa-refresh' id='search-icon' aria-hidden='true'></i>"
        . "</div>";

include "php-src/forms/sum_form.php";

include "php-src/forms/word_form.php";

//echo "</div>";

echo "<div class='step-2 btn-section hide'>
    <div class='ddl-menu-primary'><button class='export-btn ddl-menu-button' onclick='return false;'>Download Data</button>
    <i class='fa fa-download' aria-hidden='true'></i>
    <div class='ddl-menu-content'><a href='#' onclick='return exportSummaryXLS(\"summary.xlsx\");'>Download XLS<i class='fa fa-file-excel-o' aria-hidden='true'></i></a>
    <a href='#' id='word-export'>Download Word<i class='fa fa-file-word-o' aria-hidden='true'></i></a></div></div>
    <button class='next-btn' disabled>Show Graphs</button><i class='fa fa-chevron-right' aria-hidden='true'></i>
    </div>";

echo "</form>";
echo "</div>";