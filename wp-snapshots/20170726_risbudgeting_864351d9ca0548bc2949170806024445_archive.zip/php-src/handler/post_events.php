<?php

include 'php-src/db_func/save_dt.php';

$user_id = 1;



if ($_SERVER["REQUEST_METHOD"] == "POST" && (isset($_POST['data-analysis']) || isset($_POST['save-data']))) {
    
    
    
    save_input($conn,$user_id);    
}
