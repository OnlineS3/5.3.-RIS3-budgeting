
<h2>About</h2>

<p>The RIS3 budgeting tool gives the user the possibility to insert and manage 
    budgeting data in a structured way through a web-based dashboard. Filling 
    data into a series of standardised nested tables, the application provides 
    users with an overview of the RIS3 financial plan as well as with customized 
    tables and charts.</p>

<p>The logical steps of the application, based on its methodological description are:</p>

<ul class='dashed'>
    <li><i>Step 1.</i> Selection of the <strong>years</strong> for the elaboration of the RIS3 Budgeting. </li>
    <li><i>Step 2.</i> Definition of the <strong>priorities</strong> under which specific measures are grouped. </li>
    <li><i>Step 3.</i> <strong>Insertion of data</strong> into the standardised nested budget tables in the measure level. </li>
    <li><i>Step 4.</i> Generation of the <strong>RIS3 budgeting overview.</strong> </li>
    <li><i>Step 5.</i> Selection of <strong>grouping variables</strong> and application of <strong>filters</strong> to the data.</li>
    <li><i>Step 6.</i> <strong>Export</strong> budgeting tables and charts in table or image format. </li>
</ul>

<p>Following the application architecture described in previous steps, the 
    information flows within the application are given in <strong>Figure 1</strong>, below. 
    As the figure illustrates, the initial input comes from the user, who has 
    to define the time period to which the financial plan refers to, as well as 
    the priorities of the RIS3 strategy. Once this information is inserted, the 
    budgeting tables are generated and the user can start inserting more detailed 
    data regarding budget values and other characteristics per measure. For each 
    priority defined before, a separate table is provided and for each measure 
    users have to provide information regarding (i) the operational programme 
    under which this measure is funded, (ii) the thematic objective, (iii) the 
    intervention field, (iv) the form of finance and (v) the funding source.  
</p>

<p>As far as the budget values are concerned, users are asked to define the 
    amount of money that has been planned to be spent, the committed and the 
    spent one per year. When all the necessary data is uploaded, users can save 
    their progress and proceed to the analysis of these data. Variables can be 
    grouped in several ways and different filters can be adapted so that the 
    users can obtain the form of data they desire. All tables and graphics can 
    be individually extracted through the application in Table and Picture format. 
</p>

<div class='img-container'>
<img class="modal-img" id="about-img" src="images/about_3.png" alt="Figure 1. Overview of the RIS3 Budgeting application" width="750">

<div class="modal" id="myModal">
    <a class="close" id="about-close">&times;</a>
    <img class="modal-content" id="about-content">
    <div class="modal-caption" id="about-caption"></div>
</div>
</div>
<p class='img-caption'>Figure 1. Overview of the RIS3 Budgeting application</p>



