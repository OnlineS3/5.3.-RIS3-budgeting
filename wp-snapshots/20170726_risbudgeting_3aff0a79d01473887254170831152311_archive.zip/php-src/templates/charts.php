<?php

echo "<div class='step-3 content hide'>";

$graph_regions = $graph_years = $bar_data = array();
$budget_type = '';

$published_vals = get_published_values($conn,$user_id);

$regions = $published_vals['regions'];

if (count($regions) == 0) {
    echo '<p class="no-data">No published data available.</p>';
} else {

    echo "<form action='$home' id='charts' method='post'>";

    include 'php-src/forms/filter_charts.php';


    if (isset($_POST['show-bar'])) {
        $chart_data = $published_vals['chart_data'];

    if ($chart_data) {

        foreach ($graph_regions as $region) {

            $unset_region = array();
            $region_data = array_filter($chart_data, function ($item) use ($region) {
                if (stripos($item['region'], $region) !== false) {
                    return true;
                }
                return false;
            });


            if($region_data) {
                array_push($unset_region,$region_data[0]['region']);
                foreach($region_data as $row) {
                    if(!in_array($row['year'], $graph_years)) {
                        continue;
                    }
                    foreach($row as $key=>$cell) {
                        if ($key==$budget_type) {
                            array_push($unset_region,$cell);
                        }
                    }
                }
            }

            array_push($bar_data,$unset_region);
        }

        $graph_cols = $graph_years;
        $vars = $graph_regions;

        array_unshift($graph_cols, '');
        array_unshift($bar_data, $graph_cols);

        $bar_data = json_encode($bar_data);
        $legends = json_encode($vars);
        $bar_label = 'testing';

        ?>
        <script type="text/javascript">
            showAjaxBar({ container: "graph", data: <?php echo $bar_data ?>, vars: <?php echo $legends ?>, title: "Bar Chart", sub_title: "", width:"900" });
        </script>

        <?php

        }
    }

    echo "<div class='filter-btns chart'>"
        . "<button class='button btn-primary ' id='reset_chart'" 
        . "onclick='return clearChartFilters();'>Reset<img class='reset-icon' src='images/reset.png' width='14'></button>" 
        . "<button class='button btn-primary' id='filter_charts' name='show-bar'>Apply <i class='fa fa-search' id='search-icon'></i></button>" 
        . "</div>";

    echo "<div class='chart-container hide'>";

    include 'php-src/forms/chart_container.php';

    echo "</div>";

    echo "</div>";
}

echo "<div class='step-3 btn-section hide'>
        <div style='float:left; font-size:14px; font-family:tahoma; color:grey;'>
        <button class='btn btn-default btn-circle' onclick='return setStep(\"step-2\",\"step-3\");' style='margin-right: 6px;'>
        <i class='fa fa-arrow-left'></i></button>Data Analysis</div>";
echo "</form>";
echo "</div>";

