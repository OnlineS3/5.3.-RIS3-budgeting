<?php

function save_input($conn,$user) {
    $prio_rows = $_POST['prio_rows'];
    
    for($i=1;$i<=$prio_rows;$i++){
        $prio_id = save_prio($conn,$i,$user);
    }
    
    return $prio_id;
}

function save_prio($conn,$row,$user) {
    $prio = $_POST[$row . '_priority'];
    $comment = $_POST[$row . '_comment'];
    
    $prio_id = exec_ins($conn, "INSERT INTO priority (user_id,description,comment) "
                . "VALUES ($user,'$prio','$comment')");
    
    $rows = 'measure_rows_' . $row;
    $measure_rows = $_POST[$rows];
    
    for($i=1;$i<=$measure_rows;$i++){
        $measure_id = save_measure($conn,$row,$i,$prio_id);
    }
    
    return $prio_id;
}

function save_measure($conn,$prio_row,$mea_row,$prio) {
    $measure_name = $prio_row . '_' . $mea_row . '_measure';
    $measure = $_POST[$measure_name];
    
    $measure_id = exec_ins($conn, "INSERT INTO measure (prio_id,description) "
                . "VALUES ($prio,'$measure')");
    
    $rows = 'budget_rows_' . $prio_row . '_' . $mea_row;
    $budget_rows = $_POST[$rows];
    
    for($i=1;$i<=$budget_rows;$i++){
        $budget_id = save_budget($conn,$prio_row,$mea_row,$i,$measure_id);
    }
    
    return $measure_id;
}

function save_budget($conn,$prio_row,$mea_row,$budget_row,$measure_id) {
    $programme_name = $prio_row . '_' . $mea_row . '_' . $budget_row . '_programme';
    $object_name = $prio_row . '_' . $mea_row . '_' . $budget_row . '_object';
    $inter_name = $prio_row . '_' . $mea_row . '_' . $budget_row . '_inter';
    $finance_name = $prio_row . '_' . $mea_row . '_' . $budget_row . '_finance';
    $funding_name = $prio_row . '_' . $mea_row . '_' . $budget_row . '_funding';
    
    $programme_val = $_POST[$programme_name];
    $object_val = $_POST[$object_name];
    $inter_val = $_POST[$inter_name];
    $finance_val = $_POST[$finance_name];
    $funding_val = ($_POST[$funding_name]) ? $_POST[$funding_name] : 0;
    
    $budget_id = exec_ins($conn, "INSERT INTO budget (measure,programme,object,inter,finance,funding) "
                . "VALUES ($measure_id,'$programme_val','$object_val','$inter_val','$finance_val',$funding_val)");
    
    $years = explode(" ",$_POST['years']);
    
    for ($i=1;$i<count($years);$i++) {
        $budget_val_id = save_budget_val($conn,$prio_row,$mea_row,$budget_row,$years[$i],$budget_id);
    }
    
    return $budget_id;
}

function save_budget_val($conn,$prio_row,$mea_row,$budget_row,$year,$budget_id) {
    $planned_name = $prio_row . '_' . $mea_row . '_' . $budget_row . '_' . $year . '_planned';
    $commit_name = $prio_row . '_' . $mea_row . '_' . $budget_row . '_' . $year . '_commit';
    $spent_name = $prio_row . '_' . $mea_row . '_' . $budget_row . '_' . $year . '_spent';
    
    $planned_val = ($_POST[$planned_name]) ? $_POST[$planned_name] : 0;
    $commit_val = ($_POST[$commit_name]) ? $_POST[$planned_name] : 0;
    $spent_val = ($_POST[$spent_name]) ? $_POST[$spent_name] : 0;
    
    $budget_val_id = exec_ins($conn, "INSERT INTO budget_val "
                . "VALUES ($budget_id,'$year',$planned_val,$commit_val,$spent_val)");
    
    return $budget_val_id;
}