<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['filter_results'])) {
    
    $group_type = $_POST['group_col'][0];
        
    $prio_filters=$programme_filters=$object_filters=$inter_filters=$fin_filters=$fund_filters=array();
    
    $filters = array('prio'=>$prios,'programme'=>$programmes,'object'=>$objects,
        'inter'=>$inters,'finance'=>$finances,'funding'=>$funds);
    
    $summary_tbl = get_summary($conn,$user_id,$filters,$show_col,$group_type);
    
    $headers = array('group_col'=>$group_type,'prio'=>'Priority','programme'=>'Programme','object'=>'Objective',
        'inter'=>'Intervention','finance'=>'Finance','funding'=>'Funding',
        'year'=>'Year','planned_val'=>'Planned Value','committed_val'=>'Committed Value','spent_val'=>'Spent Value');

    if(count($summary_tbl)>0) {
        $years = array_unique(array_map(function ($i) { return $i['year']; }, $summary_tbl));
        $budget_tbl = array('year','planned','commit','spent');
    }
    
    echo "<div class='results'>";
    echo "<table class='budget-table summary'>";
    echo "<thead>";
    $i=0;
    foreach ($headers as $key=>$header) {
        
        if(($show_cols[$key]==1) && $key != $group_type) {
            $cls = ($key == 'group_col') ? 'group_col' : '';
            $val = ($key == 'group_col') ? $headers[$header] : $header;
            echo "<th class='$cls'>$val</th>";
            $i++;
        }
    }
    
    if(count($summary_tbl)>0) {
        foreach ($years as $year) {
            echo "<th style='padding-bottom:0'><table class='budget-headers'><tr><td colspan='3' class='year-header'>$year</td></tr><tr><td>Planned Value</td><td>Committed Value</td><td>Spent Value</td></tr></table></th>";
        }
    }
    
    echo "</thead>";
    echo "<tbody>";
    
    $budget_res = array();
    if($summary_tbl) {
        $group_prev = '';
        $z=0;
        foreach ($summary_tbl as $row) {
            $group_val = $row['row_id'];
            
            foreach ($row as $key=>$cell) {
                if (in_array($key, $budget_tbl)) {
                    $budget_res[$z][$key] = $cell;
                }
            }
                
            if ($group_prev==$group_val) {
                $planned_val = $budget_res[$z]['planned'];
                $committed_val = $budget_res[$z]['commit'];
                $spent_val = $budget_res[$z]['spent'];
                echo "<td class='budget-vals'><table><tr><td>$planned_val</td><td>$committed_val</td><td>$spent_val</td></tr></table></td>";
                continue;
            }
            
            echo "<tr>";
            $i=0;
            
            foreach ($row as $key=>$cell) {
                if(($show_cols[$key]==1) && $key != $group_type) {
                    
                    if(strripos($cell,',') == strlen($cell)-1) {
                        $cell = substr($cell,1,strlen($cell)-2);
                    }
                    
                    if ($key == 'group_col') {
                        $cell = ($group_type == 'object' || $group_type == 'finance' || $group_type == 'funding' ) ? $row['row_id'] . '-' . $row['group_col'] : $row['group_col'];
                        $cls = 'group_col';
                    } else {
                        $cell = utf8_encode(str_replace(',','<hr>',$cell)); 
                    }
                        
                    echo "<td class='$cls'>$cell</td>";
                    $i++;
                }           
            }
            
            $planned_val = $budget_res[$z]['planned'];
            $committed_val = $budget_res[$z]['commit'];
            $spent_val = $budget_res[$z]['spent'];

            echo "<td class='budget-vals'><table><tr><td>$planned_val</td><td>$committed_val</td><td>$spent_val</td></tr></table></td>";
                    
            $group_prev = $group_val;
            $z++;
        }
    }
    
    echo "</tbody>";
    echo "</table>";
    

    echo "</div>";
}

